Orukeet metric evidence. Copyright 2026 Oruk AI.
CC BY 4.0: https://creativecommons.org/licenses/by/4.0/

Per-recording errors and word counts, computed with the original references.
Text fields contain reference SHA-256 fingerprints, not transcript text.
Cluster ranks preserve shared speaker/sentence grouping and bootstrap order.
No audio or speaker names are included. This reproduces statistics, not ASR.
Source corpora retain their own licenses; see docs/data-and-licenses.md.
