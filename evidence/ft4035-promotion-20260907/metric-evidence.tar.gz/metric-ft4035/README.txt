FT-4035 matched comparison. Run: python verify_results.py .
Integer metric records: CC BY 4.0. No audio or transcripts are included.
