Orukeet surgery metric evidence. Copyright 2026 Oruk AI. CC BY 4.0.
Stored error/word counts, reference fingerprints and pseudonymous cluster ranks.
No audio, transcript text or speaker names. Reproduces statistics, not ASR.
Run training/gabor_half/reproduce_metric_evidence.py against this directory.
